# 전력 예측 및 피크 분석 재현

## 환경과 실행
Python 3.13.1에서 검증. 새 가상환경에서 다음 명령을 실행한다.
```
python -m pip install -r requirements.txt
python -X utf8 run_submission.py all
```
Jupyter에서는 reproduce.ipynb를 순서대로 실행한다. 전체 연구는 수분 이상 걸린다. CPU 모델만 사용하며 네트워크는 패키지 설치 외에 필요 없다. 현재 저장된 결과는 expected_results에 보존되어 재실행 결과와 독립적으로 비교할 수 있다.

## 구성
- data/original.csv: 공식 학습용 원자료, 변경하지 않는다.
- outputs/adaptive_v2: 과거 실행과의 차이 진단을 위한 이전 결과 두 파일. 모델 훈련·새 후보 채택에 사용하지 않는다.
- outputs/submission/test_predictions.csv: 고정된 모델의 8/1~9/14 4,320개 구간 예측.
- test_daily_peak_predictions.csv: 별도 일최대 출력. 96구간의 최대와 같을 필요는 없다.
- expected_results: 전체 설정·결과·실패·그림. 전체 실행으로 outputs에 새 결과 생성.
- docs: 사전 설계와 결과·외부자료 출처·평가 추적표.

## 해석
D-1 16시 이후 실측 기온·생산량·전력은 입력에 금지한다. 4~6월 expanding 검증으로 판단하고 7월은 이미 본 사후 진단이다. 8~9월도 과거 연구에서 이미 사용했으므로 새 독립 테스트가 아니다. H6는 구간 곡선의 성능 변화 없이 별도 일최대 MAE를 개선한다. 새 현장 검증·통계적 우위는 미확정이다. 이동 시뮬레이션의 생산량 보존은 조건부 장부이며 설비별 실행 가능성의 증거가 아니다. 요금은 2026 단가를 2021 부하에 가상 적용한다.

## 제출 형식
이 ZIP은 연구 재현용이다. 보고서·발표자료는 별도 PDF/PPTX로 제공한다. 팀 정보·서명·실제 설문 완료 화면은 참가자가 제공해야 한다. 원문 공지/양식의 예시 개인 정보와 계정·컴퓨터 경로는 포함하지 않는다. FILE_MANIFEST.json은 배포 파일의 SHA256이다.
